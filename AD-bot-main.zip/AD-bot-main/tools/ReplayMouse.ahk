ReplayRouteClick(action, x, y, held, isPlaying) {
    global GAME
    gameHwnd := WinActive(GAME)
    if !gameHwnd || !isPlaying.Call()
        return

    button := SubStr(action, 1, 1) = "l" ? "LButton" : "RButton"
    press := SubStr(action, 2, 1) = "d"
    if ReplayClickNeedsPosition(action, x, y, held) {
        MouseMove Integer(x) + 6, Integer(y) + 6, 0
        Sleep 40
        if !isPlaying.Call() || !WinActive("ahk_id " gameHwnd)
            return
        MouseMove Integer(x), Integer(y), 0
        Sleep 60
        if !isPlaying.Call() || !WinActive("ahk_id " gameHwnd)
            return
    }

    if press
        held[button] := true
    Click((button = "LButton" ? "Left" : "Right") . (press ? " Down" : " Up"))
    if !press && held.Has(button)
        held.Delete(button)
}

ReplayClickNeedsPosition(action, x, y, held) {
    if !IsInteger(x) || !IsInteger(y) || action = "ru" || held.Has("RButton")
        return false

    ; Legacy Shift Lock clicks use the center of the bot's 1920x1017
    ; client at (0,23). A recorded center click is a button event.
    if Integer(x) = 960 && Integer(y) = 531
        return false

    ; Camera capture can hide the Windows cursor or confine it to one spot.
    cursor := Buffer(16 + A_PtrSize, 0)
    NumPut "UInt", cursor.Size, cursor
    if DllCall("user32\GetCursorInfo", "Ptr", cursor) && NumGet(cursor, 4, "UInt") = 0
        return false

    clip := Buffer(16, 0)
    if DllCall("user32\GetClipCursor", "Ptr", clip)
        && NumGet(clip, 8, "Int") - NumGet(clip, 0, "Int") <= 2
        && NumGet(clip, 12, "Int") - NumGet(clip, 4, "Int") <= 2
        return false

    MouseGetPos &currentX, &currentY
    return Integer(x) != currentX || Integer(y) != currentY
}
